package weka;

import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;
import weka.filters.unsupervised.attribute.NominalToBinary;
import weka.classifiers.trees.RandomForest; // Corrected import for RandomForest
import weka.classifiers.Evaluation;
import java.util.Random;

public class EventClassifier {
    public static void main(String[] args) {
        try {
            // Load ARFF file
            DataSource source = new DataSource("event_data.arff");
            Instances data = source.getDataSet();

            // Set class attribute (eventType is the first attribute)
            data.setClassIndex(0);

            // Convert text attributes (eventName, location, description) into numeric word vectors
            StringToWordVector textFilter = new StringToWordVector();
            textFilter.setInputFormat(data);
            data = Filter.useFilter(data, textFilter);

            // Convert categorical attributes (eventType) into binary attributes for better processing
            NominalToBinary nominalFilter = new NominalToBinary();
            nominalFilter.setInputFormat(data);
            data = Filter.useFilter(data, nominalFilter);

            // Train classifier (RandomForest)
            RandomForest model = new RandomForest(); // Use RandomForest classifier
            model.buildClassifier(data);

            // Evaluate the model using 10-fold cross-validation
            Evaluation eval = new Evaluation(data);
            eval.crossValidateModel(model, data, 10, new Random(1));

            // Display evaluation results
            System.out.println("=== Random Forest Model Evaluation ===");
            System.out.println(eval.toSummaryString());
            System.out.println("Confusion Matrix OF Random Forest Model:");
            System.out.println(eval.toMatrixString());

            // Display accuracy
            System.out.println("Accuracy Of Random Forest Model: " + eval.pctCorrect() + "%");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
