package event_management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class RSVPDAO {
    public static void addRSVP(int eventId, int userId, String status, int attendees) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "INSERT INTO rsvp (event_id, user_id, status, attendees) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, eventId);
            stmt.setInt(2, userId);
            stmt.setString(3, status);
            stmt.setInt(4, attendees);
            stmt.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static List<RSVP> getRSVPsForEvent(int eventId) {
        List<RSVP> rsvpList = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM rsvp WHERE event_id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, eventId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                rsvpList.add(new RSVP(rs.getInt("id"), rs.getInt("event_id"),
                        rs.getInt("user_id"), rs.getString("status"), rs.getInt("attendees")));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return rsvpList;
    }
}
