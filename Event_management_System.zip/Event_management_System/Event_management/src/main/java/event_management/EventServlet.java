package event_management;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/event")
public class EventServlet extends HttpServlet {
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            response.sendRedirect("login.jsp?error=Please log in first.");
            return;
        }

        String action = request.getParameter("action");
        if (action == null) {
            response.sendRedirect("admin.jsp?error=Invalid action.");
            return;
        }

        switch (action) {
            case "add":
                addEvent(request, response, user);
                break;
            case "update":
                updateEvent(request, response, user);
                break;
            case "delete":
                deleteEvent(request, response, user);
                break;
            default:
                response.sendRedirect("admin.jsp?error=Invalid action.");
                break;
        }
    }
    
    public static List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            System.out.println("Database connected successfully.");  // Debugging
            String query = "SELECT * FROM events";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                System.out.println("Event found: " + rs.getString("title")); // Debugging
                events.add(new Event(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getDate("event_date"),
                    rs.getString("location"),
                    rs.getString("description"),
                    rs.getString("event_type"),
                    rs.getInt("created_by")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return events;
    }


    private void addEvent(HttpServletRequest request, HttpServletResponse response, User user)
            throws IOException {
        if (!"organizer".equalsIgnoreCase(user.getRole())) {  // Change from "admin" to "organizer"
            response.sendRedirect("admin.jsp?error=Unauthorized action.");
            return;
        }

        String title = request.getParameter("title");
        String date = request.getParameter("date");
        String location = request.getParameter("location");
        String description = request.getParameter("description");
        String type = request.getParameter("type");

        if (title == null || date == null || location == null || type == null) {
            response.sendRedirect("add_event.jsp?error=All fields are required.");
            return;
        }

        try (Connection con = DBConnection.getConnection()) {
            String query = "INSERT INTO events (title, event_date, location, description, event_type, created_by) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, title);
                stmt.setString(2, date);
                stmt.setString(3, location);
                stmt.setString(4, description);
                stmt.setString(5, type);
                stmt.setInt(6, user.getId());
                stmt.executeUpdate();
            }

            response.sendRedirect("admin.jsp?success=Event added successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("add_event.jsp?error=Failed to add event.");
        }
    }


    private void updateEvent(HttpServletRequest request, HttpServletResponse response, User user) 
            throws IOException {
        if (!"organizer".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect("admin.jsp?error=Unauthorized action.");
            return;
        }

        int eventId = Integer.parseInt(request.getParameter("eventId"));
        String title = request.getParameter("title");
        String eventDate = request.getParameter("event_date");
        String location = request.getParameter("location");
        String eventType = request.getParameter("event_type");
        String description = request.getParameter("description");

        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE events SET title=?, event_date=?, location=?, event_type=?, description=? WHERE id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, title);
            stmt.setString(2, eventDate);
            stmt.setString(3, location);
            stmt.setString(4, eventType);
            stmt.setString(5, description);
            stmt.setInt(6, eventId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                response.sendRedirect("admin.jsp?success=Event updated successfully.");
            } else {
                response.sendRedirect("admin.jsp?error=Failed to update event.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("admin.jsp?error=Database error.");
        }
    }


    private void deleteEvent(HttpServletRequest request, HttpServletResponse response, User user)
            throws IOException {
        if (!"organizer".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect("admin.jsp?error=Unauthorized action.");
            return;
        }

        String eventIdStr = request.getParameter("eventId");
        if (eventIdStr == null || eventIdStr.isEmpty()) {
            response.sendRedirect("admin.jsp?error=Invalid event ID.");
            return;
        }

        try {
            int eventId = Integer.parseInt(eventIdStr);

            try (Connection con = DBConnection.getConnection()) {
                String query = "DELETE FROM events WHERE id=?";
                try (PreparedStatement stmt = con.prepareStatement(query)) {
                    stmt.setInt(1, eventId);
                    int rowsAffected = stmt.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        response.sendRedirect("admin.jsp?success=Event deleted successfully.");
                    } else {
                        response.sendRedirect("admin.jsp?error=Event not found or already deleted.");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("admin.jsp?error=Failed to delete event.");
            }
        } catch (NumberFormatException e) {
            response.sendRedirect("admin.jsp?error=Invalid event ID format.");
        }
    }

    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            HttpSession session = request.getSession();
            User user = (User) session.getAttribute("user");

            if (user == null) {
                response.sendRedirect("login.jsp?error=Please log in first.");
                return;
            }

            deleteEvent(request, response, user);
        } else {
            // Existing code to display events
            List<Event> events = new ArrayList<>();
            try (Connection con = DBConnection.getConnection()) {
                String query = "SELECT * FROM events ORDER BY event_date DESC";
                try (PreparedStatement stmt = con.prepareStatement(query)) {
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            events.add(new Event(
                                    rs.getInt("id"),
                                    rs.getString("title"),
                                    rs.getDate("event_date"),
                                    rs.getString("location"),
                                    rs.getString("description"),
                                    rs.getString("event_type"),
                                    rs.getInt("created_by")));
                        }
                    }
                }

                request.setAttribute("events", events);
                request.getRequestDispatcher("events.jsp").forward(request, response);
             // Redirect to events.jsp with success message
                response.sendRedirect("events.jsp?success=RSVP submitted successfully!");
            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("events.jsp?error=Failed to load events.");
            }
        }
    }}

