package event_management;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        System.out.println("Login Attempt: " + email); // Debugging log

        User user = validateUser(email, password);

        if (user != null) {
            System.out.println("User Found: " + user.getEmail() + " - Role: " + user.getRole()); // Debugging

            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            session.setAttribute("userRole", user.getRole().toLowerCase());

            // Correct redirection with return statement
            if ("organizer".equalsIgnoreCase(user.getRole())) {
                response.sendRedirect("admin.jsp");
                return;
            } else {
                response.sendRedirect("events.jsp");
                return;
            }
        } else {
            System.out.println("Login Failed: Invalid credentials"); // Debugging
            response.sendRedirect("login.jsp?error=Invalid credentials");
        }
    }

    private User validateUser(String email, String password) {
        User user = null;
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                user = new User(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("password"),
                    rs.getString("role")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return user;
    }
}
