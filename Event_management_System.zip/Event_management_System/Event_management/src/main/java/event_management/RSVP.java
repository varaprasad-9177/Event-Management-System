package event_management;

public class RSVP {
    private int id;
    private int eventId;
    private int userId;
    private String status;
    private int attendees;

    public RSVP(int id, int eventId, int userId, String status, int attendees) {
        this.id = id;
        this.eventId = eventId;
        this.userId = userId;
        this.status = status;
        this.attendees = attendees;
    }

    public int getId() { return id; }
    public int getEventId() { return eventId; }
    public int getUserId() { return userId; }
    public String getStatus() { return status; }
    public int getAttendees() { return attendees; }
}
