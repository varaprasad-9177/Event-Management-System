package event_management;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {
    // Get all events
    public static List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM events";
            PreparedStatement stmt = con.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                events.add(new Event(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getDate("event_date"),
                    rs.getString("location"),
                    rs.getString("description"),
                    rs.getString("event_type"),
                    rs.getInt("created_by")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return events;
    }

    // Delete event by ID
    public static boolean deleteEvent(int eventId) {
        boolean rowDeleted = false;
        try (Connection con = DBConnection.getConnection()) {
            String query = "DELETE FROM events WHERE id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, eventId);
            rowDeleted = stmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }

    // Get event by ID
    public static Event getEventById(int id) {
        Event event = null;
        try (Connection con = DBConnection.getConnection()) {
            String query = "SELECT * FROM events WHERE id=?";
            PreparedStatement stmt = con.prepareStatement(query);
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                event = new Event(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getDate("event_date"),
                    rs.getString("location"),
                    rs.getString("description"),
                    rs.getString("event_type"),
                    rs.getInt("created_by")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return event;
    }
}
