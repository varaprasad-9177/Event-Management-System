CREATE DATABASE EventManagement;
USE EventManagement;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'organizer') NOT NULL
);
CREATE TABLE events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    event_date DATE NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT,
    event_type ENUM('Conference', 'Wedding', 'Workshop', 'Party') NOT NULL,
    created_by INT,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE rsvp (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    status ENUM('Going', 'Not Going') NOT NULL,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

ALTER TABLE rsvp ADD COLUMN attendees INT NOT NULL DEFAULT 1;



USE EventManagement;

-- Insert Default Organizer (Admin)
INSERT INTO users (name, email, password, role)
VALUES ('Admin', 'admin12@gmail.com', 'admin1234', 'organizer');

INSERT INTO users (name, email, password, role) VALUES
('John Doe', 'john.doe@example.com', 'password123', 'user'),
('Jane Smith', 'jane.smith@example.com', 'password456', 'user'),
('Alice Brown', 'alice.brown@example.com', 'password789', 'organizer');


-- Insert 20 Sample Events
INSERT INTO events (title, event_date, location, description, event_type, created_by)
VALUES 
('Tech Conference 2025', '2025-04-15', 'New York', 'A conference about the latest in technology.', 'Conference', 1),
('AI Workshop', '2025-05-10', 'San Francisco', 'Learn about artificial intelligence and machine learning.', 'Workshop', 1),
('Spring Wedding', '2025-06-20', 'Los Angeles', 'A beautiful wedding ceremony.', 'Wedding', 1),
('Summer Party', '2025-07-15', 'Miami Beach', 'A fun-filled summer party.', 'Party', 1),
('Blockchain Seminar', '2025-08-25', 'Chicago', 'Understanding blockchain technology.', 'Conference', 1),
('Digital Marketing Bootcamp', '2025-09-12', 'Seattle', 'A hands-on digital marketing workshop.', 'Workshop', 1),
('Autumn Wedding', '2025-10-05', 'Boston', 'A lovely autumn wedding.', 'Wedding', 1),
('Halloween Party', '2025-10-31', 'Las Vegas', 'A spooky Halloween celebration.', 'Party', 1),
('Cybersecurity Summit', '2025-11-20', 'Washington D.C.', 'A conference on cybersecurity trends.', 'Conference', 1),
('Christmas Gala', '2025-12-24', 'New York', 'A festive Christmas celebration.', 'Party', 1),
('Startup Networking Event', '2026-01-15', 'San Jose', 'Meet investors and entrepreneurs.', 'Conference', 1),
('Python Programming Workshop', '2026-02-10', 'Denver', 'Learn Python programming from experts.', 'Workshop', 1),
('Luxury Wedding Expo', '2026-03-05', 'Dallas', 'Showcasing luxurious wedding themes.', 'Wedding', 1),
('Spring Fashion Party', '2026-04-22', 'Los Angeles', 'A stylish party for fashion enthusiasts.', 'Party', 1),
('AI & Robotics Conference', '2026-05-18', 'San Francisco', 'Exploring the future of AI and robotics.', 'Conference', 1),
('Public Speaking Workshop', '2026-06-08', 'Austin', 'Improve your public speaking skills.', 'Workshop', 1),
('Beachside Wedding', '2026-07-25', 'Hawaii', 'A romantic wedding by the beach.', 'Wedding', 1),
('Startup Pitch Night', '2026-08-14', 'Chicago', 'Pitch your startup idea to investors.', 'Conference', 1),
('Music & Dance Party', '2026-09-30', 'Nashville', 'An exciting night of music and dance.', 'Party', 1),
('Health & Wellness Expo', '2026-10-20', 'San Diego', 'A conference on health and wellness.', 'Conference', 1);



